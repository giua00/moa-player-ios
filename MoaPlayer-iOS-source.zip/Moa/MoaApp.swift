import SwiftUI
import AVKit
import UniformTypeIdentifiers

@main
struct MoaApp: App {
    @StateObject private var store = PlayerStore()
    var body: some Scene { WindowGroup { MoaView().environmentObject(store) } }
}

struct MoaView: View {
    @EnvironmentObject var store: PlayerStore
    @AppStorage("theme") private var themeID = 0
    @State private var page = 0
    @State private var urlPanel = false
    @State private var query = ""
    @State private var url = ""
    @State private var audio = true
    @State private var showHistory = false
    @State private var importing = false
    @State private var folderImporting = false
    @State private var fullscreen = false
    @State private var about = false
    private var theme: Theme { Theme.all.first { $0.id == themeID } ?? Theme.all[0] }

    var body: some View {
        VStack(spacing: 12) {
            header
            if urlPanel { urlInput }
            if page == 1 { searchInput }
            if page == 2, store.current != nil {
                videoSurface
                Text(store.current?.title ?? "").font(.subheadline).lineLimit(2)
                Spacer(minLength: 0)
            } else if page == 1 {
                ScrollView {
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 155, maximum: 230))], spacing: 16) {
                        ForEach(store.results) { entry in resultCard(entry) }
                    }
                }
                .overlay { if store.searching { ProgressView("검색 중…").padding().background(.regularMaterial, in: RoundedRectangle(cornerRadius: 12)) } }
            } else {
                List {
                    ForEach(store.library) { entry in
                        Button { Task { await store.play(entry); if entry.video { page = 2 } } } label: {
                            HStack(spacing: 12) {
                                Image(systemName: entry.video ? "film" : "music.note").foregroundStyle(theme.accent)
                                Text(entry.title).lineLimit(2).foregroundStyle(.primary)
                                Spacer(minLength: 0)
                                if store.current?.id == entry.id { Image(systemName: "waveform").foregroundStyle(theme.accent) }
                            }.padding(.vertical, 6)
                        }.listRowBackground(Color.primary.opacity(0.04))
                            .swipeActions { Button("삭제", role: .destructive) { store.delete(entry) } }
                    }
                }.listStyle(.plain).scrollContentBackground(.hidden)
                    .overlay { if store.library.isEmpty { ContentUnavailableView("내 목록", systemImage: "music.note.list", description: Text("메뉴에서 파일을 추가하거나 유튜브 음원·영상을 저장하세요.")) } }
            }
            if store.current != nil { transport }
            if !store.status.isEmpty { Text(store.status).font(.caption).foregroundStyle(.secondary).lineLimit(2) }
        }
        .padding(14)
        .background(theme.background.ignoresSafeArea())
        .tint(theme.accent)
        .preferredColorScheme(theme.dark ? .dark : .light)
        .buttonStyle(MoaButtonStyle())
        .task { await RuntimeSmoke.run(store) }
        .overlay {
            if store.loading { ProgressView("재생 준비 중…").padding().background(.regularMaterial, in: RoundedRectangle(cornerRadius: 12)) }
        }
        .fileImporter(isPresented: $importing, allowedContentTypes: [.audio, .movie], allowsMultipleSelection: true) { result in
            do { store.importFiles(try result.get()) } catch { store.error = error.localizedDescription }
        }
        .fileImporter(isPresented: $folderImporting, allowedContentTypes: [.folder]) { result in
            do {
                let folder = try result.get()
                let access = folder.startAccessingSecurityScopedResource()
                defer { if access { folder.stopAccessingSecurityScopedResource() } }
                let files = FileManager.default.enumerator(at: folder, includingPropertiesForKeys: [.isRegularFileKey], options: [.skipsHiddenFiles])
                var urls: [URL] = []
                while let item = files?.nextObject() as? URL {
                    if let type = UTType(filenameExtension: item.pathExtension), type.conforms(to: .audio) || type.conforms(to: .movie) { urls.append(item) }
                }
                store.importFiles(urls)
            } catch { store.error = error.localizedDescription }
        }
        .fullScreenCover(isPresented: $fullscreen) {
            VStack {
                HStack { Spacer(); Button("전체화면 닫기") { fullscreen = false }.padding() }
                VideoCanvas(player: store.player) { store.toggle() }
                transport.padding()
            }.background(.black).foregroundStyle(.white).environmentObject(store)
        }
        .alert("모아", isPresented: Binding(get: { store.error != nil }, set: { if !$0 { store.error = nil } })) {
            Button("확인", role: .cancel) { store.error = nil }
        } message: { Text(store.error ?? "") }
        .sheet(isPresented: $about) {
            NavigationStack {
                ScrollView {
                    Text("모아 플레이어 iPhone 1.0\n\n파일은 이 iPhone의 모아 폴더에 저장됩니다. 파일 앱에서 확인할 수 있습니다.\n\n저장한 파일은 인터넷 없이 재생할 수 있습니다. 온라인 검색·재생·다운로드에는 인터넷이 필요합니다. 긴 다운로드는 앱을 화면에 열어두세요.\n\n본인 소유 또는 다운로드가 허용된 콘텐츠를 이용하세요.\n\n무료 설치 서명은 7일마다 갱신이 필요합니다.\n\n오픈소스 고지\nFreeTube (MIT), YouTubeKit (MIT), PythonKit, Python-iOS, certifi 및 yt-dlp/ejs를 사용합니다. 라이선스 원문은 앱 번들에 포함되어 있습니다.").padding()
                    ForEach(["FreeTube-MIT", "yt-dlp-ejs-LICENSE", "yt-dlp-ejs-THIRD-PARTY"], id: \.self) { name in
                        if let path = Bundle.main.url(forResource: name, withExtension: "txt"), let text = try? String(contentsOf: path, encoding: .utf8) {
                            Text(text).font(.caption).padding()
                        }
                    }
                }.navigationTitle("앱 정보").toolbar { Button("닫기") { about = false } }
            }
        }
    }

    private var header: some View {
        VStack(spacing: 8) {
          HStack(spacing: 8) {
            Image(systemName: "music.note.square.fill").font(.title).foregroundStyle(theme.accent)
            Text("모아").font(.title3)
            Spacer(minLength: 0)
            Menu {
                Button("내 목록", systemImage: "music.note.list") { page = 0 }
                if store.current?.video == true { Button("재생 화면", systemImage: "play.rectangle") { page = 2 } }
                Button("파일 추가", systemImage: "doc.badge.plus") { importing = true }
                Button("폴더 추가", systemImage: "folder.badge.plus") { folderImporting = true }
                Button("저장 위치: 파일 앱 → 나의 iPhone → 모아", systemImage: "folder") { about = true }
                Menu("테마") { ForEach(Theme.all) { item in Button { themeID = item.id } label: { if themeID == item.id { Label(item.name, systemImage: "checkmark") } else { Text(item.name) } } } }
                Button("앱 정보", systemImage: "info.circle") { about = true }
            } label: { Text("메뉴") }
          }
          HStack {
            Button("+URL 다운") { urlPanel.toggle(); showHistory = false }
            Button("+검색 다운") { page = page == 1 ? 0 : 1; urlPanel = false; showHistory = false }
            Spacer()
          }
        }.font(.caption)
    }

    private var urlInput: some View {
        VStack(spacing: 8) {
            Picker("다운로드 형식", selection: $audio) { Text("음원 · M4A").tag(true); Text("영상 · MP4").tag(false) }.pickerStyle(.segmented)
            HStack {
                TextField("유튜브 주소", text: $url).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL).textFieldStyle(.roundedBorder)
                Button("다운로드") { Task { await store.download(url, audio: audio) } }.disabled(store.downloading)
            }
            if store.downloading { ProgressView() }
        }.padding(10).background(.primary.opacity(0.05), in: RoundedRectangle(cornerRadius: 10))
    }

    private var searchInput: some View {
        VStack(spacing: 4) {
            HStack {
                TextField("YouTube 검색", text: $query).textFieldStyle(.roundedBorder).submitLabel(.search)
                    .onTapGesture { showHistory = true }
                    .onChange(of: query) { _, _ in showHistory = true }
                    .onSubmit { runSearch(query) }
                Button { showHistory.toggle() } label: { Image(systemName: "chevron.down") }.accessibilityLabel("검색 기록")
                Button("검색") { runSearch(query) }.disabled(store.searching)
            }
            if showHistory, !store.history.isEmpty {
                VStack(spacing: 0) {
                    ForEach(store.history.filter { query.isEmpty || $0.localizedCaseInsensitiveContains(query) }.prefix(5), id: \.self) { entry in
                        HStack {
                            Button { runSearch(entry) } label: { HStack { Image(systemName: "clock"); Text(entry).lineLimit(1); Spacer() } }
                            Button { store.forget(entry) } label: { Image(systemName: "xmark") }.accessibilityLabel("\(entry) 기록 삭제")
                        }
                    }
                    Button("기록 전체 삭제", role: .destructive) { store.forget() }
                }.font(.subheadline).padding(6).background(.regularMaterial, in: RoundedRectangle(cornerRadius: 8))
            }
        }
    }
    private func runSearch(_ value: String) {
        query = value; showHistory = false
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
        Task { await store.search(value) }
    }

    private func resultCard(_ entry: MediaEntry) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Button { Task { await store.play(entry); if store.current?.id == entry.id { page = 2 } } } label: {
                VStack(alignment: .leading, spacing: 6) {
                    AsyncImage(url: entry.thumbnail) { image in image.resizable().scaledToFill() } placeholder: { Rectangle().fill(.gray.opacity(0.2)) }
                        .frame(height: 100).clipped().clipShape(RoundedRectangle(cornerRadius: 8))
                    Text(entry.title).font(.caption).lineLimit(2).frame(height: 34, alignment: .topLeading).foregroundStyle(.primary)
                }
            }.buttonStyle(.plain)
            HStack {
                Button("음원 다운") { Task { await store.download(entry.source, audio: true) } }
                Button("영상 다운") { Task { await store.download(entry.source, audio: false) } }
            }.font(.caption2).disabled(store.downloading)
        }
    }
    private var videoSurface: some View {
        ZStack {
            if fullscreen {
                Color.black.aspectRatio(16 / 9, contentMode: .fit)
            } else {
                VideoCanvas(player: store.player) { store.toggle() }.aspectRatio(16 / 9, contentMode: .fit)
            }
            if store.loading { ProgressView().tint(.white) }
        }.background(.black).clipShape(RoundedRectangle(cornerRadius: 8))
    }
    private var transport: some View {
        VStack(spacing: 6) {
            if page != 2 {
                if store.current?.video == true {
                    Button { page = 2 } label: { Text(store.current?.title ?? "").font(.caption).lineLimit(1) }
                } else { Text(store.current?.title ?? "").font(.caption).lineLimit(1) }
            }
            Slider(value: Binding(get: { min(store.position, max(store.duration, 1)) }, set: { store.seek($0) }), in: 0...max(store.duration, 1))
            HStack { Text(clock(store.position)); Spacer(); Text(clock(store.duration)) }.font(.caption2).foregroundStyle(.secondary).monospacedDigit()
            HStack {
                Button { store.next(-1) } label: { Image(systemName: "backward.end.fill") }.accessibilityLabel("이전")
                Button { store.seek(store.position - 10) } label: { Image(systemName: "gobackward.10") }
                Button { store.toggle() } label: { Image(systemName: store.playing ? "pause.fill" : "play.fill").frame(width: 30) }.accessibilityLabel("재생 / 일시정지")
                Button { store.seek(store.position + 10) } label: { Image(systemName: "goforward.10") }
                Button { store.next(1) } label: { Image(systemName: "forward.end.fill") }.accessibilityLabel("다음")
                Spacer(minLength: 0)
                Button { store.repeatOne.toggle() } label: { Image(systemName: store.repeatOne ? "repeat.1" : "repeat").opacity(store.repeatOne ? 1 : 0.45) }
                if store.current?.video == true { Button { fullscreen.toggle() } label: { Image(systemName: "arrow.up.left.and.arrow.down.right") }.accessibilityLabel("전체화면") }
            }.font(.body)
        }
    }
    private func clock(_ value: Double) -> String {
        let total = Int(max(0, value))
        if total >= 3600 { return String(format: "%d:%02d:%02d", total / 3600, (total / 60) % 60, total % 60) }
        return String(format: "%d:%02d", total / 60, total % 60)
    }
}

struct MoaButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.padding(.horizontal, 8).padding(.vertical, 9)
            .background(.primary.opacity(configuration.isPressed ? 0.20 : 0.07), in: RoundedRectangle(cornerRadius: 7))
            .scaleEffect(configuration.isPressed ? 0.96 : 1)
    }
}

final class PlayerLayerView: UIView {
    override class var layerClass: AnyClass { AVPlayerLayer.self }
    var playerLayer: AVPlayerLayer { layer as! AVPlayerLayer }
    var onTap: (() -> Void)?
    var playbackPlayer: AVPlayer? {
        didSet { playerLayer.player = UIApplication.shared.applicationState == .active ? playbackPlayer : nil }
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
        addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(tapped)))
        backgroundColor = .black
        // Detach the video surface before backgrounding so AVPlayer may keep
        // playing the audio under the app's audio background mode.
        NotificationCenter.default.addObserver(self, selector: #selector(detachVideo), name: UIApplication.willResignActiveNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(restoreVideo), name: UIApplication.didBecomeActiveNotification, object: nil)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not used") }
    @objc private func tapped() { onTap?() }
    @objc private func detachVideo() { playerLayer.player = nil }
    @objc private func restoreVideo() { playerLayer.player = playbackPlayer }
    deinit { NotificationCenter.default.removeObserver(self) }
}
struct VideoCanvas: UIViewRepresentable {
    let player: AVPlayer
    var onTap: () -> Void
    func makeUIView(context: Context) -> PlayerLayerView { PlayerLayerView() }
    func updateUIView(_ view: PlayerLayerView, context: Context) { view.playbackPlayer = player; view.playerLayer.videoGravity = .resizeAspect; view.onTap = onTap }
}
