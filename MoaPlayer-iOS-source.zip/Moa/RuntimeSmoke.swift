import Foundation
import AVFoundation

@MainActor
enum RuntimeSmoke {
    static func run(_ store: PlayerStore) async {
        guard ProcessInfo.processInfo.arguments.contains("--runtime-smoke") else { return }
        let report = store.documents.appendingPathComponent("runtime-smoke.json")
        do {
            let version = try await Extractor.shared.selfTest()
            let data = wave()
            let name = "runtime-smoke.wav"
            try data.write(to: store.documents.appendingPathComponent(name))
            await store.play(MediaEntry(id: "smoke", title: "오프라인 재생 검사", file: name, video: false))
            for _ in 0..<20 {
                if store.player.currentItem?.status == .readyToPlay, store.player.currentTime().seconds > 0.1 { break }
                try await Task.sleep(for: .milliseconds(250))
            }
            guard store.player.currentItem?.status == .readyToPlay, store.player.currentTime().seconds > 0.1 else {
                throw MoaError.message("Offline AVPlayer did not start: \(String(describing: store.player.currentItem?.error))")
            }
            store.player.pause()
            let result: [String: Any] = ["passed": true, "extractor": version, "pythonJSBridge": true, "offlineAudio": true]
            try JSONSerialization.data(withJSONObject: result, options: .prettyPrinted).write(to: report, options: .atomic)
        } catch {
            let result: [String: Any] = ["passed": false, "error": error.localizedDescription]
            try? JSONSerialization.data(withJSONObject: result, options: .prettyPrinted).write(to: report, options: .atomic)
        }
    }

    private static func wave() -> Data {
        var data = Data()
        func ascii(_ text: String) { data.append(contentsOf: text.utf8) }
        func u16(_ value: UInt16) { data.append(UInt8(value & 255)); data.append(UInt8(value >> 8)) }
        func u32(_ value: UInt32) { for shift in stride(from: 0, to: 32, by: 8) { data.append(UInt8((value >> shift) & 255)) } }
        let frames = 24000
        ascii("RIFF"); u32(UInt32(36 + frames * 2)); ascii("WAVEfmt "); u32(16)
        u16(1); u16(1); u32(8000); u32(16000); u16(2); u16(16); ascii("data"); u32(UInt32(frames * 2))
        data.append(Data(repeating: 0, count: frames * 2))
        return data
    }
}
