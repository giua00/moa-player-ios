import SwiftUI
import AVFoundation
import MediaPlayer
import YouTubeKit
import UniformTypeIdentifiers

struct MediaEntry: Identifiable, Codable, Sendable {
    var id: String
    var title: String
    var file: String?
    var video: Bool = true
    var thumbnail: URL? { URL(string: "https://i.ytimg.com/vi/\(id)/mqdefault.jpg") }
    var source: String { "https://www.youtube.com/watch?v=\(id)" }
}

struct Theme: Identifiable {
    let id: Int
    let name: String
    let background: Color
    let accent: Color
    let dark: Bool
    static let all: [Theme] = [
        .init(id: 0, name: "라벤더", background: Color(red: 0.09, green: 0.09, blue: 0.14), accent: .purple, dark: true),
        .init(id: 1, name: "민트", background: Color(red: 0.05, green: 0.12, blue: 0.15), accent: .mint, dark: true),
        .init(id: 2, name: "샌드", background: Color(red: 0.15, green: 0.16, blue: 0.16), accent: Color(red: 0.85, green: 0.76, blue: 0.56), dark: true),
        .init(id: 3, name: "크림", background: Color(red: 0.98, green: 0.96, blue: 0.92), accent: .brown, dark: false),
        .init(id: 4, name: "오션", background: Color(red: 0.04, green: 0.10, blue: 0.19), accent: .cyan, dark: true),
        .init(id: 5, name: "로즈", background: Color(red: 0.18, green: 0.08, blue: 0.12), accent: .pink, dark: true),
        .init(id: 6, name: "포레스트", background: Color(red: 0.06, green: 0.13, blue: 0.09), accent: .green, dark: true),
        .init(id: 7, name: "모노", background: Color(white: 0.08), accent: .gray, dark: true),
        .init(id: 8, name: "스노우", background: Color(white: 0.97), accent: .indigo, dark: false),
        .init(id: 9, name: "선셋", background: Color(red: 0.18, green: 0.10, blue: 0.07), accent: .orange, dark: true)
    ]
}

@MainActor
final class PlayerStore: ObservableObject {
    @Published var library: [MediaEntry] = []
    @Published var results: [MediaEntry] = []
    @Published var history: [String] = []
    @Published var current: MediaEntry?
    @Published var status = ""
    @Published var searching = false
    @Published var downloading = false
    @Published var loading = false
    @Published var playing = false
    @Published var repeatOne = false
    @Published var position: Double = 0
    @Published var duration: Double = 0
    @Published var error: String?
    let player = AVPlayer()
    let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    private var observer: Any?
    private var endObserver: NSObjectProtocol?
    private var failureObservation: NSKeyValueObservation?
    private var playToken = UUID()

    init() {
        if let data = try? Data(contentsOf: documents.appendingPathComponent("library.json")),
           let list = try? JSONDecoder().decode([MediaEntry].self, from: data) { library = list }
        history = UserDefaults.standard.stringArray(forKey: "searchHistory") ?? []
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .moviePlayback)
            try AVAudioSession.sharedInstance().setActive(true)
        } catch { self.error = error.localizedDescription }
        observer = player.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.5, preferredTimescale: 600), queue: .main) { [weak self] _ in
            Task { @MainActor in
                guard let self else { return }
                let elapsed = self.player.currentTime().seconds
                self.position = elapsed.isFinite ? elapsed : 0
                let length = self.player.currentItem?.duration.seconds ?? 0
                self.duration = length.isFinite ? length : 0
                self.playing = self.player.timeControlStatus == .playing
                self.updateNowPlaying()
            }
        }
        endObserver = NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: nil, queue: .main) { [weak self] note in
            Task { @MainActor in
                guard let self, note.object as? AVPlayerItem === self.player.currentItem else { return }
                if self.repeatOne { self.seek(0); self.player.play() } else { self.next(1) }
            }
        }
        let commands = MPRemoteCommandCenter.shared()
        commands.playCommand.addTarget { [weak self] _ in Task { @MainActor in self?.player.play() }; return .success }
        commands.pauseCommand.addTarget { [weak self] _ in Task { @MainActor in self?.player.pause() }; return .success }
        commands.togglePlayPauseCommand.addTarget { [weak self] _ in Task { @MainActor in self?.toggle() }; return .success }
        commands.nextTrackCommand.addTarget { [weak self] _ in Task { @MainActor in self?.next(1) }; return .success }
        commands.previousTrackCommand.addTarget { [weak self] _ in Task { @MainActor in self?.next(-1) }; return .success }
        commands.changePlaybackPositionCommand.addTarget { [weak self] event in
            guard let event = event as? MPChangePlaybackPositionCommandEvent else { return .commandFailed }
            Task { @MainActor in self?.seek(event.positionTime) }; return .success
        }
    }

    func persist() {
        do { try JSONEncoder().encode(library).write(to: documents.appendingPathComponent("library.json"), options: .atomic) }
        catch { self.error = "목록 저장 실패: \(error.localizedDescription)" }
    }

    func forget(_ query: String? = nil) {
        if let query { history.removeAll { $0 == query } } else { history.removeAll() }
        UserDefaults.standard.set(history, forKey: "searchHistory")
    }

    func search(_ text: String) async {
        let query = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !query.isEmpty, !searching else { return }
        history.removeAll { $0.caseInsensitiveCompare(query) == .orderedSame }
        history.insert(query, at: 0)
        history = Array(history.prefix(50))
        UserDefaults.standard.set(history, forKey: "searchHistory")
        searching = true
        defer { searching = false }
        do {
            let response = try await SearchResponse.sendThrowingRequest(youtubeModel: YouTubeModel(), data: [.query: query])
            results = response.results.compactMap { ($0 as? YTVideo).map { MediaEntry(id: $0.videoId, title: $0.title ?? "YouTube") } }
            status = results.isEmpty ? "검색 결과가 없습니다." : "\(results.count)개 검색됨"
        } catch { self.error = "검색 실패: \(error.localizedDescription)" }
    }

    func play(_ entry: MediaEntry) async {
        let token = UUID()
        playToken = token
        loading = true
        defer { if playToken == token { loading = false } }
        do {
            let item: AVPlayerItem
            if let file = entry.file {
                let path = documents.appendingPathComponent(file)
                guard FileManager.default.fileExists(atPath: path.path) else { throw MoaError.message("저장한 파일을 찾을 수 없습니다.") }
                item = AVPlayerItem(url: path)
            } else {
                let stream = try await Extractor.shared.resolve(entry.source, audio: false, allowHLS: true)
                guard playToken == token else { return }
                item = AVPlayerItem(asset: AVURLAsset(url: stream.url, options: ["AVURLAssetHTTPHeaderFieldsKey": stream.headers]))
            }
            guard playToken == token else { return }
            current = entry
            player.replaceCurrentItem(with: item)
            failureObservation = item.observe(\.status, options: [.new]) { [weak self] item, _ in
                if item.status == .failed {
                    let message = item.error?.localizedDescription ?? "네트워크와 영상 형식을 확인해 주세요."
                    Task { @MainActor in self?.error = "재생 실패: \(message)" }
                }
            }
            player.play()
            status = entry.file == nil ? "온라인 재생" : "아이폰에 저장된 파일 재생"
        } catch { if playToken == token { self.error = error.localizedDescription } }
    }

    func download(_ source: String, audio: Bool) async {
        guard !downloading else { return }
        guard let parsed = URL(string: source), ["youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com", "youtu.be"].contains(parsed.host?.lowercased() ?? ""), parsed.scheme == "https" else {
            error = "https://로 시작하는 유튜브 주소를 입력해 주세요."; return
        }
        downloading = true
        status = "다운로드 준비 중…"
        defer { downloading = false }
        let backgroundTask = UIApplication.shared.beginBackgroundTask(withName: "MoaDownload")
        defer { if backgroundTask != .invalid { UIApplication.shared.endBackgroundTask(backgroundTask) } }
        do {
            let stream = try await Extractor.shared.resolve(source, audio: audio)
            var request = URLRequest(url: stream.url)
            request.allHTTPHeaderFields = stream.headers
            request.timeoutInterval = 300
            status = "\(stream.title) 다운로드 중…"
            let (temporary, response) = try await URLSession.shared.download(for: request)
            defer { try? FileManager.default.removeItem(at: temporary) }
            guard let http = response as? HTTPURLResponse, http.statusCode == 200 else { throw MoaError.message("다운로드 서버가 파일을 보내지 않았습니다. 다시 시도해 주세요.") }
            let handle = try FileHandle(forReadingFrom: temporary)
            let header = try handle.read(upToCount: 32) ?? Data()
            try handle.close()
            guard header.count >= 8, String(data: header.dropFirst(4).prefix(4), encoding: .ascii) == "ftyp" else {
                throw MoaError.message("직접 저장 가능한 M4A/MP4 형식이 아닙니다. 다른 영상을 선택해 주세요.")
            }
            let identity = UUID().uuidString
            let cleanTitle = String(stream.title.unicodeScalars.map { CharacterSet(charactersIn: "/\\:\u{0000}").contains($0) ? "_" : String($0) }.joined().prefix(100))
            let file = cleanTitle + "-" + String(identity.prefix(8)) + (audio ? ".m4a" : ".mp4")
            let destination = documents.appendingPathComponent(file)
            try FileManager.default.moveItem(at: temporary, to: destination)
            library.append(MediaEntry(id: identity, title: stream.title, file: file, video: !audio))
            persist()
            status = "아이폰에 저장했습니다. 인터넷 없이 재생할 수 있습니다."
        } catch { self.error = "다운로드 실패: \(error.localizedDescription)"; status = "다운로드 실패" }
    }

    func importFiles(_ urls: [URL]) {
        for url in urls {
            let access = url.startAccessingSecurityScopedResource()
            defer { if access { url.stopAccessingSecurityScopedResource() } }
            do {
                let identity = UUID().uuidString
                let file = identity + "." + url.pathExtension.lowercased()
                try FileManager.default.copyItem(at: url, to: documents.appendingPathComponent(file))
                let type = UTType(filenameExtension: url.pathExtension)
                library.append(MediaEntry(id: identity, title: url.deletingPathExtension().lastPathComponent, file: file, video: type?.conforms(to: .movie) == true))
            } catch { self.error = error.localizedDescription }
        }
        persist()
    }

    func delete(_ entry: MediaEntry) {
        if current?.id == entry.id { playToken = UUID(); player.pause(); player.replaceCurrentItem(with: nil); current = nil }
        do {
            if let file = entry.file { try FileManager.default.removeItem(at: documents.appendingPathComponent(file)) }
            library.removeAll { $0.id == entry.id }; persist()
        } catch { self.error = error.localizedDescription }
    }
    func toggle() { player.timeControlStatus == .playing ? player.pause() : player.play() }
    func seek(_ seconds: Double) { player.seek(to: CMTime(seconds: max(0, seconds), preferredTimescale: 600)) }
    func next(_ direction: Int) {
        guard let current, let index = library.firstIndex(where: { $0.id == current.id }), !library.isEmpty else { return }
        let target = library[(index + direction + library.count) % library.count]
        Task { await play(target) }
    }
    private func updateNowPlaying() {
        guard let current else { return }
        MPNowPlayingInfoCenter.default().nowPlayingInfo = [MPMediaItemPropertyTitle: current.title, MPMediaItemPropertyPlaybackDuration: duration, MPNowPlayingInfoPropertyElapsedPlaybackTime: position, MPNowPlayingInfoPropertyPlaybackRate: playing ? 1.0 : 0.0]
    }
}
