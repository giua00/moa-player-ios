import Foundation
import PythonKit
import PythonSupport
import OSLog

public nonisolated func AppLog(subsystem: String, category: String) -> Logger {
    // Python bridge messages are retained only in the device's system log.
    Logger(subsystem: "com.moa.player.ios", category: category)
}

struct StreamInfo: Sendable {
    let title: String
    let url: URL
    let headers: [String: String]
}

enum MoaError: LocalizedError {
    case message(String)
    var errorDescription: String? {
        if case .message(let message) = self { return message }
        return nil
    }
}

/// Every Python object is created, used and released on one permanent Thread.
/// A serial DispatchQueue alone does not guarantee a stable OS thread.
final class Extractor: @unchecked Sendable {
    static let shared = Extractor()
    private let condition = NSCondition()
    private var jobs: [() -> Void] = []
    private var initialized = false

    private init() {
        let worker = Thread { [self] in
            while true {
                condition.lock()
                while jobs.isEmpty { condition.wait() }
                let job = jobs.removeFirst()
                condition.unlock()
                autoreleasepool { job() }
            }
        }
        worker.name = "Moa Python"
        worker.qualityOfService = .utility
        worker.start()
    }

    func resolve(_ input: String, audio: Bool, allowHLS: Bool = false) async throws -> StreamInfo {
        try await withCheckedThrowingContinuation { continuation in
            condition.lock()
            jobs.append { [self] in
                do { continuation.resume(returning: try extract(input, audio: audio, allowHLS: allowHLS)) }
                catch { continuation.resume(throwing: error) }
            }
            condition.signal()
            condition.unlock()
        }
    }

    @_optimize(none)
    private func extract(_ input: String, audio: Bool, allowHLS: Bool) throws -> StreamInfo {
        if !initialized {
            guard let moduleURL = Bundle.main.url(forResource: "yt-dlp", withExtension: "zip"),
                  let certificates = Bundle.main.url(forResource: "cacert", withExtension: "pem") else {
                throw MoaError.message("앱의 다운로드 리소스가 없습니다. 다시 빌드해 주세요.")
            }
            setenv("SSL_CERT_FILE", certificates.path, 1)
            PythonSupport.initialize()
            let sys = try Python.attemptImport("sys")
            sys.path.insert(0, moduleURL.path)
            // Python-iOS ships a subprocess stub. This app never launches child
            // processes; only our in-process JSC runtime may use the bridge.
            PythonSupport.runSimpleString(Self.subprocessStub)
            PythonJSBridge.install()
            initialized = true
        }
        let module = try Python.attemptImport("yt_dlp")
        var opts = PythonObject([:] as [String: PythonObject])
        opts["noplaylist"] = true
        opts["quiet"] = true
        opts["socket_timeout"] = 25
        opts["check_formats"] = true
        opts["ffmpeg_location"] = "/dev/null/no-ffmpeg"
        opts["js_runtimes"] = PythonObject(["deno": ["path": PythonJSBridge.fakeDenoPath]])
        // Only select iPhone-compatible formats. Playback never invokes download().
        let directVideo = "best[ext=mp4][vcodec^=avc1][protocol=https]"
        opts["format"] = audio ? "bestaudio[ext=m4a][protocol=https]" : (allowHLS ? directVideo + "/best[protocol*=m3u8]" : directVideo)
        let downloader = module.YoutubeDL(opts)
        let info = try downloader.extract_info.throwing.dynamicallyCall(withArguments: [input, false])
        guard let value = info.checking["url"].flatMap(String.init), let url = URL(string: value), url.scheme == "https" else {
            throw MoaError.message("이 영상에서 재생 가능한 형식을 찾지 못했습니다.")
        }
        var headers: [String: String] = [:]
        if let values = info.checking["http_headers"], let dictionary = Dictionary<String, PythonObject>(values) {
            for (key, value) in dictionary {
                if let text = String(value) { headers[key] = text }
            }
        }
        return StreamInfo(title: info.checking["title"].flatMap(String.init) ?? "YouTube", url: url, headers: headers)
    }

    private static let subprocessStub = """
    import subprocess
    class MoaProcess:
        def __init__(self, *args, **kwargs):
            raise OSError('External processes are unavailable on iOS')
        def communicate(self, *args, **kwargs):
            raise OSError('External processes are unavailable on iOS')
        def wait(self, *args, **kwargs):
            return self.returncode
        def poll(self):
            return self.returncode
        def kill(self):
            pass
        def terminate(self):
            pass
        def __enter__(self):
            return self
        def __exit__(self, *args):
            return False
    subprocess.Popen = MoaProcess
    subprocess.TimeoutExpired = TimeoutError
    subprocess.SubprocessError = OSError
    """
}
