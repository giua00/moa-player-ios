#!/bin/bash
set -euo pipefail
xcodebuild -project Moa.xcodeproj -scheme Moa -configuration Debug -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' -derivedDataPath build CODE_SIGNING_ALLOWED=NO build > simulator-build.log 2>&1
xcrun simctl list devices available -j > simulator-devices.json
sim_id=$(python3 -c 'import json; d=json.load(open("simulator-devices.json"))["devices"]; print(next(v["udid"] for k in sorted(d,reverse=True) if ".iOS-" in k for v in d[k] if "iPhone" in v["name"]))')
xcrun simctl boot "$sim_id" || true
xcrun simctl bootstatus "$sim_id" -b
xcrun simctl install "$sim_id" build/Build/Products/Debug-iphonesimulator/Moa.app
xcrun simctl launch "$sim_id" com.moa.player.ios --runtime-smoke
data_dir=$(xcrun simctl get_app_container "$sim_id" com.moa.player.ios data)
for attempt in $(seq 1 30); do
  if [ -f "$data_dir/Documents/runtime-smoke.json" ]; then break; fi
  sleep 2
done
xcrun simctl io "$sim_id" screenshot simulator-screen.png
if [ -f "$data_dir/Documents/runtime-smoke.json" ]; then
  cp "$data_dir/Documents/runtime-smoke.json" runtime-smoke.json
else
  xcrun simctl spawn "$sim_id" log show --last 3m --style compact --predicate 'process == "Moa"' > simulator-runtime.log
  echo 'App did not write a runtime smoke report.'
  exit 1
fi
cat runtime-smoke.json
python3 -c 'import json; r=json.load(open("runtime-smoke.json")); assert r["passed"],r'
